#include <iostream>
#include <windows.h>
#include "Gui/Gui.h"


 

// hi guys this is very basic colorbot for dahood games


// @0x109 



using namespace std;
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

int main()
{
    SetConsoleTitle("##ANARCHIST");
    SetConsoleTextAttribute(hConsole, 12);
    cout << "Menu - INSERT\n";
    ShowImgui();

    return 0;
}