#pragma once
#include <Windows.h>
#include <vector>
#include <cmath>

namespace Colorbot
{
    static bool enabled = false;
    static int keybind = 0;
    static int darkThreshold = 85;
    static int fovX = 100;
    static int fovY = 100;
    static float smoothX = 2.0f; 
    static float smoothY = 2.0f; 
    static float multiplier = 1.0f; 
    
    static float accumulatedX = 0.0f;
    static float accumulatedY = 0.0f;
    
    static int prevTargetX = -1;
    static int prevTargetY = -1;
    static const float MIN_MOVEMENT = 0.5f; 

    inline void SetEnabled(bool value) { enabled = value; }
    inline void SetKeybind(int key) { keybind = key; }
    inline void SetDarkThreshold(int threshold) { darkThreshold = threshold; }
    inline void SetFOV(int x, int y) { fovX = x; fovY = y; }
    inline void SetSmoothingXY(float x, float y) 
    { 
        smoothX = x; 
        smoothY = y; 
        if (smoothX < 1.0f) smoothX = 1.0f; 
        if (smoothY < 1.0f) smoothY = 1.0f; 
    }
    inline void SetMultiplier(float value)
    {
        multiplier = value;
        if (multiplier < 0.1f) multiplier = 0.1f;
        if (multiplier > 5.0f) multiplier = 5.0f;
    }

    struct PixelData
    {
        int x, y;
        float distance;
    };

    inline bool IsDark(BYTE r, BYTE g, BYTE b, int threshold)
    {
        float brightness = 0.299f * r + 0.587f * g + 0.114f * b;
        return brightness < threshold;
    }

    inline float Distance(int x1, int y1, int x2, int y2)
    {
        int dx = x2 - x1;
        int dy = y2 - y1;
        return sqrtf((float)(dx * dx + dy * dy));
    }
    
    inline int CountDarkNeighbors(const std::vector<BYTE>& pixels, int x, int y, int width, int height, int threshold)
    {
        int count = 0;
        const int NEIGHBOR_RADIUS = 3;
        
        for (int dy = -NEIGHBOR_RADIUS; dy <= NEIGHBOR_RADIUS; dy += 2)
        {
            for (int dx = -NEIGHBOR_RADIUS; dx <= NEIGHBOR_RADIUS; dx += 2)
            {
                int nx = x + dx;
                int ny = y + dy;
                
                if (nx >= 0 && nx < width && ny >= 0 && ny < height)
                {
                    int index = (ny * width + nx) * 4;
                    BYTE b = pixels[index];
                    BYTE g = pixels[index + 1];
                    BYTE r = pixels[index + 2];
                    
                    if (IsDark(r, g, b, threshold))
                        count++;
                }
            }
        }
        return count;
    }

    inline void Update()
    {
        if (!enabled || keybind == 0)
            return;

        if (!(GetAsyncKeyState(keybind) & 0x8000))
            return;

        int screenWidth = GetSystemMetrics(SM_CXSCREEN);
        int screenHeight = GetSystemMetrics(SM_CYSCREEN);

        int centerX = screenWidth / 2;
        int centerY = screenHeight / 2;

        int left = centerX - fovX;
        int top = centerY - fovY;
        int right = centerX + fovX;
        int bottom = centerY + fovY;

        if (left < 0) left = 0;
        if (top < 0) top = 0;
        if (right > screenWidth) right = screenWidth;
        if (bottom > screenHeight) bottom = screenHeight;

        int width = right - left;
        int height = bottom - top;

        HDC screenDC = GetDC(NULL);
        if (!screenDC)
            return;

        HDC memDC = CreateCompatibleDC(screenDC);
        HBITMAP hBitmap = CreateCompatibleBitmap(screenDC, width, height);
        HBITMAP hOldBitmap = (HBITMAP)SelectObject(memDC, hBitmap);

        BitBlt(memDC, 0, 0, width, height, screenDC, left, top, SRCCOPY);

        BITMAPINFO bmi = { 0 };
        bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
        bmi.bmiHeader.biWidth = width;
        bmi.bmiHeader.biHeight = -height; 
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = BI_RGB;

        std::vector<BYTE> pixels(width * height * 4);
        GetDIBits(memDC, hBitmap, 0, height, pixels.data(), &bmi, DIB_RGB_COLORS);

        std::vector<PixelData> darkPixels;
        darkPixels.reserve(2048); 

        std::vector<PixelData> coarseDarkPixels;
        for (int y = 0; y < height; y += 2)
        {
            for (int x = 0; x < width; x += 2)
            {
                int index = (y * width + x) * 4;

                BYTE b = pixels[index];
                BYTE g = pixels[index + 1];
                BYTE r = pixels[index + 2];

                if (IsDark(r, g, b, darkThreshold))
                {
                    int neighbors = CountDarkNeighbors(pixels, x, y, width, height, darkThreshold);
                    if (neighbors >= 2) 
                    {
                        int screenX = left + x;
                        int screenY = top + y;
                        float dist = Distance(centerX, centerY, screenX, screenY);
                        coarseDarkPixels.push_back({ screenX, screenY, dist });
                    }
                }
            }
        }
        
        if (!coarseDarkPixels.empty())
        {
            PixelData* coarseClosest = &coarseDarkPixels[0];
            for (size_t i = 1; i < coarseDarkPixels.size(); i++)
            {
                if (coarseDarkPixels[i].distance < coarseClosest->distance)
                    coarseClosest = &coarseDarkPixels[i];
            }
            
            const int FINE_SCAN_RADIUS = 20;
            int fineLeft = max(0, coarseClosest->x - left - FINE_SCAN_RADIUS);
            int fineTop = max(0, coarseClosest->y - top - FINE_SCAN_RADIUS);
            int fineRight = min(width, coarseClosest->x - left + FINE_SCAN_RADIUS);
            int fineBottom = min(height, coarseClosest->y - top + FINE_SCAN_RADIUS);
            
            for (int y = fineTop; y < fineBottom; y++)
            {
                for (int x = fineLeft; x < fineRight; x++)
                {
                    int index = (y * width + x) * 4;
                    BYTE b = pixels[index];
                    BYTE g = pixels[index + 1];
                    BYTE r = pixels[index + 2];
                    
                    if (IsDark(r, g, b, darkThreshold))
                    {
                        int screenX = left + x;
                        int screenY = top + y;
                        float dist = Distance(centerX, centerY, screenX, screenY);
                        darkPixels.push_back({ screenX, screenY, dist });
                    }
                }
            }
        }
        
        if (darkPixels.empty())
            darkPixels = coarseDarkPixels;

        SelectObject(memDC, hOldBitmap);
        DeleteObject(hBitmap);
        DeleteDC(memDC);
        ReleaseDC(NULL, screenDC);

        if (!darkPixels.empty())
        {
            PixelData* closest = &darkPixels[0];
            for (size_t i = 1; i < darkPixels.size(); i++)
            {
                if (darkPixels[i].distance < closest->distance)
                {
                    closest = &darkPixels[i];
                }
            }

            float clusterRadius = min(25.0f, max(8.0f, closest->distance * 0.15f));
            
            float weightedSumX = 0.0f, weightedSumY = 0.0f;
            float totalWeight = 0.0f;

            for (const auto& pixel : darkPixels)
            {
                float distToClosest = Distance(pixel.x, pixel.y, closest->x, closest->y);
                if (distToClosest <= clusterRadius)
                {
                    float weight = 1.0f / (1.0f + distToClosest);
                    weightedSumX += pixel.x * weight;
                    weightedSumY += pixel.y * weight;
                    totalWeight += weight;
                }
            }

            float targetX = totalWeight > 0 ? (weightedSumX / totalWeight) : static_cast<float>(closest->x);
            float targetY = totalWeight > 0 ? (weightedSumY / totalWeight) : static_cast<float>(closest->y);
            
            if (prevTargetX >= 0 && prevTargetY >= 0)
            {
                float velocityX = targetX - prevTargetX;
                float velocityY = targetY - prevTargetY;
                
                float predictionFactor = 0.3f; 
                targetX += velocityX * predictionFactor * (smoothX / 5.0f);
                targetY += velocityY * predictionFactor * (smoothY / 5.0f);
            }
            
            prevTargetX = static_cast<int>(targetX);
            prevTargetY = static_cast<int>(targetY);

            float deltaX = targetX - centerX;
            float deltaY = targetY - centerY;

            float moveX = deltaX / smoothX;
            float moveY = deltaY / smoothY;
            
            moveX *= multiplier;
            moveY *= multiplier;

            accumulatedX += moveX;
            accumulatedY += moveY;
            
            int finalMoveX = static_cast<int>(accumulatedX);
            int finalMoveY = static_cast<int>(accumulatedY);
            
            accumulatedX -= finalMoveX;
            accumulatedY -= finalMoveY;
            
            if (fabs(deltaX) < 2.0f && fabs(deltaY) < 2.0f)
            {
                accumulatedX *= 0.9f; 
                accumulatedY *= 0.9f;
            }

            if (finalMoveX != 0 || finalMoveY != 0)
            {
                mouse_event(MOUSEEVENTF_MOVE, finalMoveX, finalMoveY, 0, 0);
            }
        }
        else
        {
            prevTargetX = -1;
            prevTargetY = -1;
            accumulatedX *= 0.5f; 
            accumulatedY *= 0.5f;
        }
    }
}